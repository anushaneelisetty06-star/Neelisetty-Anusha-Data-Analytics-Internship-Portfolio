import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import InternshipJourney from './components/InternshipJourney';
import Projects from './components/Projects';
import Skills from './components/Skills';
import Certifications from './components/Certifications';
import KeyLearnings from './components/KeyLearnings';
import Reflection from './components/Reflection';
import Achievements from './components/Achievements';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <Hero />
        <About />
        <InternshipJourney />
        <Projects />
        <Skills />
        <Certifications />
        <KeyLearnings />
        <Reflection />
        <Achievements />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;
