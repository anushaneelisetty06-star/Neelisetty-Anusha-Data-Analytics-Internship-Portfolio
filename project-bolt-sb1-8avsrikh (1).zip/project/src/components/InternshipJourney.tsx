import { useState } from 'react';
import { CheckCircle, ArrowRight, Database, LineChart, BarChart3, BookOpen, Award } from 'lucide-react';

const milestones = [
  {
    task: 'Task 1',
    title: 'Data Immersion & Wrangling',
    description: 'Mastered data cleaning techniques, handling missing values, and transforming raw datasets into analysis-ready formats.',
    skills: ['Data Cleaning', 'Missing Value Handling', 'Data Transformation', 'Pandas'],
    icon: Database,
    color: 'from-primary to-violet',
  },
  {
    task: 'Task 2',
    title: 'EDA & Business Intelligence',
    description: 'Conducted comprehensive exploratory data analysis, identifying patterns and trends to derive business insights.',
    skills: ['Exploratory Analysis', 'Pattern Recognition', 'Statistical Analysis', 'Visualization'],
    icon: LineChart,
    color: 'from-violet to-purple',
  },
  {
    task: 'Task 3',
    title: 'Deep-Dive Analysis & Interactive Dashboarding',
    description: 'Built interactive Power BI dashboards with drill-down capabilities, KPIs, and real-time data visualization.',
    skills: ['Power BI', 'Dashboard Design', 'KPI Development', 'Interactive Reports'],
    icon: BarChart3,
    color: 'from-purple to-sky',
  },
  {
    task: 'Task 4',
    title: 'Data Storytelling & Statistical Validation',
    description: 'Crafted compelling data narratives and performed statistical tests to validate findings and hypotheses.',
    skills: ['Statistical Testing', 'Hypothesis Validation', 'Data Storytelling', 'Reporting'],
    icon: BookOpen,
    color: 'from-sky to-teal',
  },
  {
    task: 'Task 5',
    title: 'Capstone Integration & Portfolio Finalization',
    description: 'Integrated all learnings into a comprehensive capstone project and finalized the professional portfolio.',
    skills: ['Project Integration', 'Documentation', 'Portfolio Development', 'Presentation'],
    icon: Award,
    color: 'from-teal to-primary',
  },
];

export default function InternshipJourney() {
  const [activeStep, setActiveStep] = useState<number | null>(null);

  return (
    <section id="journey" className="py-20 lg:py-32 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-1/3 left-0 w-96 h-96 bg-violet/20 rounded-full blur-3xl" />
        <div className="absolute bottom-1/3 right-0 w-96 h-96 bg-primary/20 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-16">
          <h2 className="section-title">
            <span className="gradient-text">Internship Journey</span>
          </h2>
          <p className="section-subtitle">
            ApexPlanet Data Analytics Internship – A transformative learning experience
          </p>
        </div>

        {/* Timeline */}
        <div className="relative">
          {/* Vertical line */}
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-primary via-violet to-teal hidden md:block" />

          {/* Milestones */}
          <div className="space-y-8 md:space-y-12">
            {milestones.map((milestone, idx) => (
              <div
                key={idx}
                className={`relative flex flex-col md:flex-row items-start md:items-center gap-8 ${
                  idx % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                }`}
                onMouseEnter={() => setActiveStep(idx)}
                onMouseLeave={() => setActiveStep(null)}
              >
                {/* Timeline dot */}
                <div className="absolute left-4 md:left-1/2 -translate-x-1/2 z-10 hidden md:block">
                  <div
                    className={`w-12 h-12 rounded-full bg-gradient-to-br ${milestone.color} flex items-center justify-center
                               shadow-lg transition-transform duration-300 ${
                                 activeStep === idx ? 'scale-125' : ''
                               }`}
                  >
                    <milestone.icon className="w-6 h-6 text-white" />
                  </div>
                </div>

                {/* Content card */}
                <div
                  className={`ml-16 md:ml-0 md:w-5/12 ${idx % 2 === 0 ? 'md:pr-16' : 'md:pl-16'}`}
                >
                  <div
                    className={`card glass-hover transition-all duration-500 ${
                      activeStep === idx ? 'animate-glow-pulse' : ''
                    }`}
                  >
                    {/* Task badge */}
                    <div className="flex items-center gap-3 mb-4">
                      <div
                        className={`px-3 py-1 rounded-full bg-gradient-to-r ${milestone.color} text-white text-xs font-semibold`}
                      >
                        {milestone.task}
                      </div>
                      <div className="flex items-center gap-1 text-success">
                        <CheckCircle className="w-4 h-4" />
                        <span className="text-xs">Completed</span>
                      </div>
                    </div>

                    {/* Title */}
                    <h3 className="text-xl font-bold text-white mb-3">{milestone.title}</h3>

                    {/* Description */}
                    <p className="text-textSecondary mb-4 text-sm">{milestone.description}</p>

                    {/* Skills */}
                    <div className="flex flex-wrap gap-2">
                      {milestone.skills.map((skill, skillIdx) => (
                        <span
                          key={skillIdx}
                          className="px-2 py-1 text-xs rounded-md bg-white/5 text-textSecondary border border-white/10"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>

                    {/* Arrow indicator */}
                    {idx < milestones.length - 1 && (
                      <div className="hidden md:flex items-center justify-end mt-4">
                        <ArrowRight
                          className={`w-5 h-5 text-textSecondary ${
                            idx % 2 === 0 ? '' : 'rotate-180'
                          }`}
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* Mobile icon */}
                <div className="absolute left-4 -translate-x-1/2 md:hidden">
                  <div
                    className={`w-10 h-10 rounded-full bg-gradient-to-br ${milestone.color} flex items-center justify-center`}
                  >
                    <milestone.icon className="w-5 h-5 text-white" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Company badge */}
        <div className="mt-16 text-center">
          <div className="inline-flex items-center gap-3 glass px-6 py-4 rounded-2xl">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-violet flex items-center justify-center">
              <Award className="w-6 h-6 text-white" />
            </div>
            <div className="text-left">
              <div className="text-sm text-textSecondary">Internship at</div>
              <div className="text-white font-semibold">ApexPlanet Software Pvt. Ltd.</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
