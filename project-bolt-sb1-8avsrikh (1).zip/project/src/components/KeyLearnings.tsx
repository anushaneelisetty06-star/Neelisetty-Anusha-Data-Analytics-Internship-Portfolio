import { Sparkles, BookOpen, LineChart, BarChart3, Target, CheckCircle, Lightbulb, TrendingUp } from 'lucide-react';

const learnings = [
  {
    title: 'Data Cleaning',
    description: 'Mastered techniques for handling missing values, outliers, and data inconsistencies.',
    icon: Sparkles,
    color: 'from-primary to-violet',
  },
  {
    title: 'Exploratory Data Analysis',
    description: 'Developed skills in uncovering patterns, trends, and insights from complex datasets.',
    icon: LineChart,
    color: 'from-violet to-purple',
  },
  {
    title: 'KPI Design',
    description: 'Created meaningful Key Performance Indicators aligned with business objectives.',
    icon: Target,
    color: 'from-purple to-sky',
  },
  {
    title: 'Dashboard Development',
    description: 'Built interactive dashboards with drill-down capabilities and real-time updates.',
    icon: BarChart3,
    color: 'from-sky to-teal',
  },
  {
    title: 'Business Intelligence',
    description: 'Gained expertise in transforming data into actionable business recommendations.',
    icon: Lightbulb,
    color: 'from-teal to-primary',
  },
  {
    title: 'Statistical Validation',
    description: 'Applied statistical testing and hypothesis validation to confirm data insights.',
    icon: CheckCircle,
    color: 'from-primary to-violet',
  },
  {
    title: 'Storytelling with Data',
    description: 'Crafted compelling narratives that communicate insights to stakeholders.',
    icon: BookOpen,
    color: 'from-violet to-purple',
  },
  {
    title: 'Data-Driven Decision Making',
    description: 'Enabled strategic decisions through evidence-based analysis and recommendations.',
    icon: TrendingUp,
    color: 'from-purple to-sky',
  },
];

export default function KeyLearnings() {
  return (
    <section id="learnings" className="py-20 lg:py-32 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-primary/20 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-teal/20 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-16">
          <h2 className="section-title">
            <span className="gradient-text">Key Learnings</span>
          </h2>
          <p className="section-subtitle">
            Valuable skills acquired throughout the data analytics journey
          </p>
        </div>

        {/* Learnings grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {learnings.map((learning, idx) => (
            <div
              key={idx}
              className="card glass-hover group text-center"
              style={{ animationDelay: `${idx * 50}ms` }}
            >
              {/* Icon */}
              <div
                className={`w-14 h-14 mx-auto rounded-xl bg-gradient-to-br ${learning.color} flex items-center justify-center mb-4
                           group-hover:scale-110 group-hover:shadow-lg transition-all duration-300`}
              >
                <learning.icon className="w-7 h-7 text-white" />
              </div>

              {/* Title */}
              <h3 className="text-white font-semibold mb-2 group-hover:text-sky transition-colors">
                {learning.title}
              </h3>

              {/* Description */}
              <p className="text-textSecondary text-xs leading-relaxed">
                {learning.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
