import { BarChart3, Github, Linkedin, Mail } from 'lucide-react';

const socialLinks = [
  { icon: Github, href: 'https://github.com/anushaneelisetty06-star', label: 'GitHub' },
  { icon: Linkedin, href: 'https://linkedin.com/in/anusha-neelisetty', label: 'LinkedIn' },
  { icon: Mail, href: 'mailto:anusha.neelisetty06@gmail.com', label: 'Email' },
];

export default function Footer() {
  return (
    <footer className="relative pt-16 pb-8 overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-t from-card via-card/50 to-transparent" />

      {/* Decorative elements */}
      <div className="absolute bottom-0 left-1/4 w-[400px] h-[400px] bg-violet/10 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-1/4 w-[400px] h-[400px] bg-primary/10 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main content */}
        <div className="glass rounded-2xl p-8 lg:p-10 mb-8">
          <div className="flex flex-col items-center gap-8">
            {/* Brand */}
            <a href="#" className="flex items-center gap-3 group">
              <div className="p-2.5 rounded-xl bg-gradient-to-br from-primary to-violet group-hover:shadow-lg group-hover:shadow-primary/30 transition-all">
                <BarChart3 className="w-6 h-6 text-white" />
              </div>
              <div className="text-center">
                <div className="font-bold text-white text-lg">Built by Neelisetty Anusha</div>
              </div>
            </a>

            {/* Subtitle */}
            <div className="text-textSecondary text-center">
              ApexPlanet Data Analytics Internship Portfolio
            </div>

            {/* Social links */}
            <div className="flex items-center gap-3">
              {socialLinks.map((social, idx) => (
                <a
                  key={idx}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-11 h-11 rounded-xl border border-white/10 flex items-center justify-center
                           hover:bg-white/10 hover:border-primary/30 transition-all duration-300"
                  aria-label={social.label}
                >
                  <social.icon className="w-5 h-5 text-textSecondary hover:text-white transition-colors" />
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="text-center text-textSecondary text-sm pb-4">
          {new Date().getFullYear()} Neelisetty Anusha. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
