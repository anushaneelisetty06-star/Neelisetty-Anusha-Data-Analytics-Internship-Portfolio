import { CheckCircle, Trophy, Star, Award } from 'lucide-react';

const achievements = [
  { text: 'Task-1 Completed', color: 'text-primary' },
  { text: 'Task-2 Completed', color: 'text-violet' },
  { text: 'Task-3 Completed', color: 'text-purple' },
  { text: 'Task-4 Completed', color: 'text-sky' },
  { text: 'Internship Portfolio Completed', color: 'text-teal' },
  { text: 'Power BI Dashboard Developed', color: 'text-primary' },
  { text: 'Statistical Validation Performed', color: 'text-violet' },
];

export default function Achievements() {
  return (
    <section id="achievements" className="py-20 lg:py-32 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-teal/20 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-16">
          <h2 className="section-title">
            <span className="gradient-text">Achievements</span>
          </h2>
          <p className="section-subtitle">
            Milestones accomplished throughout the internship journey
          </p>
        </div>

        {/* ApexPlanet Internship Completion Badge */}
        <div className="text-center mb-16">
          <div className="inline-block glass rounded-3xl p-10 relative overflow-hidden group">
            {/* Decorative gradient */}
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-violet/10 to-teal/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

            <div className="relative">
              {/* Badge container */}
              <div className="w-32 h-32 mx-auto mb-6 rounded-full bg-gradient-to-br from-primary via-violet to-teal p-1 animate-pulse-glow">
                <div className="w-full h-full rounded-full bg-card flex items-center justify-center">
                  <Award className="w-16 h-16 text-primary" />
                </div>
              </div>

              {/* Badge text */}
              <div className="text-2xl font-bold text-white mb-2">ApexPlanet Internship</div>
              <div className="text-lg text-sky font-semibold mb-4">Completion Badge</div>

              {/* Stars */}
              <div className="flex justify-center gap-2">
                {[...Array(5)].map((_, idx) => (
                  <Star key={idx} className="w-6 h-6 text-yellow-400 fill-yellow-400" />
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Achievement badges */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 mb-12">
          {achievements.map((achievement, idx) => (
            <div
              key={idx}
              className="glass rounded-xl p-5 flex items-center gap-4 hover:bg-white/10 transition-all duration-300
                         group cursor-default"
              style={{ animationDelay: `${idx * 100}ms` }}
            >
              <div className={`w-10 h-10 rounded-full bg-gradient-to-br from-primary/20 to-violet/20 flex items-center justify-center
                              group-hover:scale-110 transition-transform duration-300`}>
                <CheckCircle className={`w-5 h-5 ${achievement.color}`} />
              </div>
              <span className="text-white font-medium text-sm group-hover:text-sky transition-colors">
                {achievement.text}
              </span>
            </div>
          ))}
        </div>

        {/* Trophy section */}
        <div className="text-center">
          <div className="inline-flex items-center gap-6 glass rounded-2xl p-8">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center
                           animate-bounce-subtle">
              <Trophy className="w-10 h-10 text-white" />
            </div>
            <div className="text-left">
              <div className="text-2xl font-bold text-white mb-1">5/5 Tasks Completed</div>
              <div className="text-textSecondary">Successfully completed all internship milestones</div>
            </div>
            <div className="flex gap-1">
              {[...Array(5)].map((_, idx) => (
                <Star key={idx} className="w-6 h-6 text-yellow-400 fill-yellow-400" />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
