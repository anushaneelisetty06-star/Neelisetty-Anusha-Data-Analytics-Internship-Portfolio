import { GraduationCap, Target, Sparkles, Lightbulb, Brain, MapPin } from 'lucide-react';

const aboutItems = [
  {
    icon: GraduationCap,
    title: 'Education',
    content: 'B.Tech – Computer Science & Engineering',
    subcontent: 'Raghu Engineering College | CGPA: 8.77',
    color: 'from-primary to-violet',
  },
  {
    icon: Target,
    title: 'Career Goal',
    content: 'To become a Data Analyst',
    subcontent: 'Leveraging analytics, BI, dashboard development, and statistical analysis',
    color: 'from-violet to-purple',
  },
  {
    icon: Sparkles,
    title: 'Technical Interests',
    content: 'Data Analytics & Business Intelligence',
    subcontent: 'Python, SQL, Power BI, Tableau',
    color: 'from-purple to-sky',
  },
  {
    icon: Brain,
    title: 'Analytics Passion',
    content: 'Transforming Data into Insights',
    subcontent: 'Data visualization, storytelling & decision-making',
    color: 'from-sky to-teal',
  },
  {
    icon: Lightbulb,
    title: 'Problem-Solving',
    content: 'Analytical Mindset',
    subcontent: 'Turning complex problems into solutions',
    color: 'from-teal to-primary',
  },
  {
    icon: MapPin,
    title: 'Location',
    content: 'Andhra Pradesh, India',
    subcontent: 'Open to remote & on-site opportunities',
    color: 'from-primary to-violet',
  },
];

export default function About() {
  return (
    <section id="about" className="py-20 lg:py-32 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-1/4 -left-32 w-64 h-64 bg-primary/20 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 -right-32 w-64 h-64 bg-violet/20 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-16">
          <h2 className="section-title">
            <span className="gradient-text">About Me</span>
          </h2>
          <p className="section-subtitle">
            Passionate about turning data into meaningful insights that drive business decisions
          </p>
        </div>

        {/* Split layout */}
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left side - Image/Visual */}
          <div className="relative">
            <div className="relative aspect-square max-w-md mx-auto">
              {/* Animated rings */}
              <div className="absolute inset-0 rounded-full border border-primary/30 animate-spin-slow" />
              <div className="absolute inset-4 rounded-full border border-violet/30 animate-spin-slow" style={{ animationDirection: 'reverse' }} />
              <div className="absolute inset-8 rounded-full border border-purple/30 animate-spin-slow" />

              {/* Center content */}
              <div className="absolute inset-12 glass rounded-full flex items-center justify-center">
                <div className="text-center p-8">
                  <div className="text-5xl font-bold gradient-text mb-2">8.77</div>
                  <div className="text-textSecondary text-sm">CGPA</div>
                </div>
              </div>

              {/* Floating badges */}
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 glass px-4 py-2 rounded-full animate-float">
                <span className="text-sky text-sm font-medium">Python</span>
              </div>
              <div className="absolute top-1/4 -right-4 glass px-4 py-2 rounded-full animate-float-delayed">
                <span className="text-violet text-sm font-medium">Power BI</span>
              </div>
              <div className="absolute bottom-1/4 -left-4 glass px-4 py-2 rounded-full animate-float-slow">
                <span className="text-teal text-sm font-medium">SQL</span>
              </div>
              <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 glass px-4 py-2 rounded-full animate-float">
                <span className="text-purple text-sm font-medium">Tableau</span>
              </div>
            </div>
          </div>

          {/* Right side - Info grid */}
          <div className="grid sm:grid-cols-2 gap-4">
            {aboutItems.map((item, idx) => (
              <div
                key={idx}
                className="card glass-hover group"
                style={{ animationDelay: `${idx * 100}ms` }}
              >
                <div
                  className={`w-12 h-12 rounded-xl bg-gradient-to-br ${item.color} flex items-center justify-center mb-4
                             group-hover:scale-110 transition-transform duration-300`}
                >
                  <item.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">{item.title}</h3>
                <p className="text-textSecondary text-sm mb-1">{item.content}</p>
                <p className="text-textSecondary/60 text-xs">{item.subcontent}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Career Goal Highlight */}
        <div className="mt-16 glass rounded-2xl p-8 md:p-12 text-center relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-transparent to-violet/10" />
          <div className="relative">
            <Target className="w-12 h-12 text-primary mx-auto mb-6" />
            <h3 className="text-2xl md:text-3xl font-bold text-white mb-4">Career Vision</h3>
            <p className="text-textSecondary max-w-3xl mx-auto leading-relaxed">
              To become a <span className="text-primary font-medium">Data Analyst</span> and leverage{' '}
              <span className="text-violet font-medium">data analytics</span>,{' '}
              <span className="text-purple font-medium">business intelligence</span>,{' '}
              <span className="text-sky font-medium">dashboard development</span>, and{' '}
              <span className="text-teal font-medium">statistical analysis</span> to solve real-world
              business problems through data-driven decision-making.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
