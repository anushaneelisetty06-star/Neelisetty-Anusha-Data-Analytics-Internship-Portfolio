import { Github, ExternalLink, Database, LineChart, BarChart3, BookOpen, Wrench } from 'lucide-react';

const projects = [
  {
    task: 'Task 1',
    title: 'Data Immersion & Wrangling',
    description: 'Comprehensive data cleaning and transformation of COVID-19 datasets. Handled missing values, standardized formats, and prepared data for analysis.',
    skills: ['Python', 'Pandas', 'Data Cleaning', 'Missing Values', 'Data Transformation'],
    repo: 'https://github.com/anushaneelisetty06-star/covid_19---data-immersion-and-wrangling-.git',
    icon: Database,
    color: 'from-primary to-violet',
  },
  {
    task: 'Task 2',
    title: 'EDA & Business Intelligence',
    description: 'Performed exploratory data analysis on COVID-19 data to uncover patterns, trends, and business-relevant insights using statistical methods.',
    skills: ['Python', 'Matplotlib', 'Statistical Analysis', 'Pattern Recognition', 'EDA'],
    repo: 'https://github.com/anushaneelisetty06-star/EDA-and-Business-Intelligence.git',
    icon: LineChart,
    color: 'from-violet to-purple',
  },
  {
    task: 'Task 3',
    title: 'Deep-Dive Analysis & Interactive Dashboarding',
    description: 'Built an interactive Power BI dashboard with KPIs, drill-down capabilities, and real-time visualizations for COVID-19 analytics.',
    skills: ['Power BI', 'DAX', 'Dashboard Design', 'KPI Development', 'Visualization'],
    repo: 'https://github.com/anushaneelisetty06-star/COVID-19-Business-Intelligence-Dashboard.git',
    icon: BarChart3,
    color: 'from-purple to-sky',
  },
  {
    task: 'Task 4',
    title: 'Data Storytelling & Statistical Validation',
    description: 'Crafted compelling data narratives and performed statistical tests including hypothesis testing to validate COVID-19 findings.',
    skills: ['Statistical Testing', 'Hypothesis Validation', 'Data Storytelling', 'Python', 'Reporting'],
    repo: 'https://github.com/anushaneelisetty06-star/COVID19-Data-Storytelling-Statistical-Validation.git',
    icon: BookOpen,
    color: 'from-sky to-teal',
  },
];

export default function Projects() {
  return (
    <section id="projects" className="py-20 lg:py-32 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-0 right-1/4 w-[600px] h-[600px] bg-purple/20 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-1/4 w-[600px] h-[600px] bg-primary/20 rounded-full blur-3xl" />
      </div>

      {/* Gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-card/10 to-transparent" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-16">
          <h2 className="section-title">
            <span className="gradient-text">Featured Projects</span>
          </h2>
          <p className="section-subtitle">
            Comprehensive data analytics projects showcasing end-to-end analytical capabilities
          </p>
        </div>

        {/* Projects grid */}
        <div className="grid md:grid-cols-2 gap-6 lg:gap-8">
          {projects.map((project, idx) => (
            <div
              key={idx}
              className="glass rounded-2xl p-6 lg:p-8 relative overflow-hidden group transition-all duration-500 hover:shadow-2xl hover:shadow-primary/10"
            >
              {/* Decorative corner gradient */}
              <div className={`absolute -top-20 -right-20 w-40 h-40 bg-gradient-to-br ${project.color} opacity-20 rounded-full blur-2xl
                              group-hover:opacity-40 group-hover:scale-150 transition-all duration-700`} />

              <div className="relative">
                {/* Header */}
                <div className="flex items-start justify-between mb-6">
                  <div
                    className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${project.color} flex items-center justify-center
                               group-hover:scale-110 group-hover:rotate-3 transition-all duration-300 shadow-lg`}
                    style={{ boxShadow: '0 10px 40px -10px rgba(37, 99, 235, 0.5)' }}
                  >
                    <project.icon className="w-8 h-8 text-white" />
                  </div>
                  <span
                    className={`px-4 py-1.5 rounded-full bg-gradient-to-r ${project.color} text-white text-xs font-semibold shadow-lg`}
                  >
                    {project.task}
                  </span>
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold text-white mb-4 group-hover:text-sky transition-colors">
                  {project.title}
                </h3>
                <p className="text-textSecondary text-sm mb-6 leading-relaxed">
                  {project.description}
                </p>

                {/* Technologies Used */}
                <div className="mb-6">
                  <div className="flex items-center gap-2 mb-3">
                    <Wrench className="w-4 h-4 text-primary" />
                    <span className="text-xs text-textSecondary font-medium uppercase tracking-wider">Technologies Used</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {project.skills.map((skill, skillIdx) => (
                      <span
                        key={skillIdx}
                        className="px-3 py-1.5 text-xs rounded-lg bg-white/5 text-textSecondary border border-white/10
                                   hover:border-primary/30 hover:bg-primary/10 hover:text-white transition-all duration-300"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Actions */}
                <div className="pt-4 border-t border-white/10">
                  <a
                    href={project.repo}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-primary to-violet rounded-lg text-white text-sm font-medium
                               hover:shadow-lg hover:shadow-primary/30 hover:scale-105 transition-all duration-300"
                  >
                    <Github className="w-4 h-4" />
                    View on GitHub
                    <ExternalLink className="w-3.5 h-3.5 ml-1 opacity-70" />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* View all projects */}
        <div className="mt-12 text-center">
          <a
            href="https://github.com/anushaneelisetty06-star"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 btn-secondary"
          >
            <Github className="w-5 h-5" />
            View All Projects on GitHub
            <ExternalLink className="w-4 h-4 opacity-70" />
          </a>
        </div>
      </div>
    </section>
  );
}
