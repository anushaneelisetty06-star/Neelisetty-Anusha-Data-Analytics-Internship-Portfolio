import { Download, FolderKanban, Github, Linkedin, TrendingUp, Award, Code2, PieChart, BarChart3, Database, Activity, LineChart, Layers } from 'lucide-react';
import { useEffect, useState } from 'react';

const kpis = [
  { icon: Award, label: 'CGPA', value: 8.77, suffix: '', color: 'from-primary to-violet' },
  { icon: Code2, label: 'Internship Projects', value: 4, suffix: '', color: 'from-violet to-purple' },
  { icon: TrendingUp, label: 'Technical Skills', value: 10, suffix: '+', color: 'from-purple to-sky' },
  { icon: PieChart, label: 'Power BI Dashboards', value: 0, suffix: 'Multiple', color: 'from-sky to-teal' },
];

const floatingElements = [
  { icon: BarChart3, delay: '0s', x: 'left-[8%]', y: 'top-[15%]', size: 'w-20 h-20', opacity: 'opacity-10' },
  { icon: Database, delay: '1.5s', x: 'right-[10%]', y: 'top-[20%]', size: 'w-14 h-14', opacity: 'opacity-8' },
  { icon: Activity, delay: '2.5s', x: 'left-[15%]', y: 'bottom-[30%]', size: 'w-12 h-12', opacity: 'opacity-6' },
  { icon: PieChart, delay: '3s', x: 'right-[12%]', y: 'bottom-[25%]', size: 'w-16 h-16', opacity: 'opacity-8' },
  { icon: TrendingUp, delay: '0.5s', x: 'left-[5%]', y: 'top-[50%]', size: 'w-10 h-10', opacity: 'opacity-5' },
  { icon: LineChart, delay: '4s', x: 'right-[5%]', y: 'top-[55%]', size: 'w-8 h-8', opacity: 'opacity-6' },
  { icon: Layers, delay: '2s', x: 'left-[25%]', y: 'bottom-[15%]', size: 'w-14 h-14', opacity: 'opacity-7' },
];

function AnimatedCounter({ value, suffix }: { value: number; suffix: string }) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    const duration = 2000;
    const steps = 60;
    const increment = value / steps;
    let current = 0;
    const timer = setInterval(() => {
      current += increment;
      if (current >= value) {
        setCount(value);
        clearInterval(timer);
      } else {
        setCount(Math.floor(current * 100) / 100);
      }
    }, duration / steps);
    return () => clearInterval(timer);
  }, [value]);

  if (suffix === 'Multiple') return <span className="text-lg">Multiple</span>;
  if (suffix) return <span>{suffix}</span>;
  return <span>{count}</span>;
}

export default function Hero() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Multi-layer gradient background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-violet/10 to-background" />
        <div className="absolute inset-0 bg-gradient-to-tl from-sky/10 via-transparent to-purple/10" />
        <div className="absolute inset-0 bg-gradient-to-b from-background via-transparent to-background" />
      </div>

      {/* Animated mesh gradient */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/30 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-violet/30 rounded-full blur-3xl animate-float-slow" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-purple/20 rounded-full blur-3xl animate-pulse-glow" />
      </div>

      {/* Floating elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {floatingElements.map((el, idx) => (
          <div
            key={idx}
            className={`absolute ${el.x} ${el.y} ${el.opacity} animate-float`}
            style={{ animationDelay: el.delay }}
          >
            <el.icon className={`${el.size} text-primary`} />
          </div>
        ))}
      </div>

      {/* Grid pattern overlay */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                           linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
          backgroundSize: '60px 60px',
        }}
      />

      {/* Radial gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-background/50 via-transparent to-background" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="text-center">
          {/* Main headline */}
          <h1
            className={`text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold mb-6 ${
              isVisible ? 'animate-slide-up' : 'opacity-0'
            }`}
          >
            <span className="text-white">Neelisetty Anusha</span>
          </h1>

          <h2
            className={`text-2xl sm:text-3xl md:text-4xl font-semibold mb-4 ${
              isVisible ? 'animate-slide-up animate-delay-200' : 'opacity-0'
            }`}
          >
            <span className="gradient-text">Data Analyst Portfolio & Internship Journey</span>
          </h2>

          {/* Subtitle */}
          <p
            className={`text-lg md:text-xl text-textSecondary mb-10 ${
              isVisible ? 'animate-slide-up animate-delay-400' : 'opacity-0'
            }`}
          >
            ApexPlanet Data Analytics Internship Portfolio
          </p>

          {/* Description */}
          <p
            className={`text-lg md:text-xl text-textSecondary max-w-4xl mx-auto mb-12 leading-relaxed ${
              isVisible ? 'animate-slide-up animate-delay-600' : 'opacity-0'
            }`}
          >
            Aspiring Data Analyst passionate about{' '}
            <span className="text-sky font-medium">Data Analytics</span>,{' '}
            <span className="text-violet font-medium">Business Intelligence</span>,{' '}
            <span className="text-teal font-medium">Interactive Dashboard Development</span>,{' '}
            <span className="text-purple font-medium">Data Storytelling</span>,{' '}
            <span className="text-primary font-medium">Statistical Validation</span>, and{' '}
            <span className="text-sky font-medium">Data-Driven Decision Making</span>.
          </p>

          {/* CTA Buttons */}
          <div
            className={`flex flex-wrap justify-center gap-4 mb-20 ${
              isVisible ? 'animate-slide-up animate-delay-800' : 'opacity-0'
            }`}
          >
            <button className="btn-primary flex items-center gap-2 px-8">
              <Download className="w-5 h-5" />
              Download Resume
            </button>
            <a href="#projects" className="btn-secondary flex items-center gap-2 px-8">
              <FolderKanban className="w-5 h-5" />
              View Projects
            </a>
            <a
              href="https://github.com/anushaneelisetty06-star"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-secondary flex items-center gap-2 px-6"
            >
              <Github className="w-5 h-5" />
              GitHub
            </a>
            <a
              href="https://linkedin.com/in/anusha-neelisetty"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-secondary flex items-center gap-2 px-6"
            >
              <Linkedin className="w-5 h-5" />
              LinkedIn
            </a>
          </div>

          {/* KPI Cards */}
          <div
            className={`grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 max-w-5xl mx-auto ${
              isVisible ? 'animate-slide-up animate-delay-800' : 'opacity-0'
            }`}
          >
            {kpis.map((kpi, idx) => (
              <div
                key={idx}
                className="glass glass-hover text-center p-6 rounded-2xl group relative overflow-hidden"
                style={{ animationDelay: `${1000 + idx * 100}ms` }}
              >
                {/* Glow effect */}
                <div
                  className={`absolute inset-0 bg-gradient-to-br ${kpi.color} opacity-0 group-hover:opacity-10 transition-opacity duration-500`}
                />

                <div
                  className={`w-14 h-14 mx-auto mb-4 rounded-2xl bg-gradient-to-br ${kpi.color} flex items-center justify-center
                             group-hover:scale-110 group-hover:shadow-lg group-hover:shadow-primary/30 transition-all duration-300`}
                >
                  <kpi.icon className="w-7 h-7 text-white" />
                </div>
                <div className="text-3xl lg:text-4xl font-bold text-white mb-2">
                  <AnimatedCounter value={kpi.value} suffix={kpi.suffix} />
                </div>
                <div className="text-sm text-textSecondary font-medium">{kpi.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce-subtle">
          <div className="w-7 h-12 rounded-full border-2 border-white/20 flex items-start justify-center p-2">
            <div className="w-1.5 h-3 bg-gradient-to-b from-primary to-violet rounded-full animate-pulse" />
          </div>
        </div>
      </div>
    </section>
  );
}
