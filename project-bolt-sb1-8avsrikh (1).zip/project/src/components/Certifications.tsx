import { Award, CheckCircle } from 'lucide-react';

const certifications = [
  {
    title: 'Python Certification',
    issuer: 'Certified',
    description: 'Comprehensive Python programming certification covering fundamentals to advanced concepts for data analytics.',
    color: 'from-primary to-violet',
  },
  {
    title: 'SQL Certification',
    issuer: 'Certified',
    description: 'Database querying and management certification with advanced SQL techniques for data analysis.',
    color: 'from-violet to-purple',
  },
  {
    title: 'Deloitte Data Analytics Job Simulation',
    issuer: 'Deloitte',
    description: 'Completed job simulation program focused on real-world data analytics scenarios and business intelligence.',
    color: 'from-purple to-sky',
  },
  {
    title: 'Unified Mentor Data Analytics Internship',
    issuer: 'Unified Mentor',
    description: 'Successfully completed comprehensive data analytics internship program with hands-on projects.',
    color: 'from-sky to-teal',
  },
];

export default function Certifications() {
  return (
    <section id="certifications" className="py-20 lg:py-32 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-violet/20 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-16">
          <h2 className="section-title">
            <span className="gradient-text">Certifications</span>
          </h2>
          <p className="section-subtitle">
            Professional certifications validating expertise in data analytics
          </p>
        </div>

        {/* Certifications grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {certifications.map((cert, idx) => (
            <div
              key={idx}
              className="glass glass-hover rounded-2xl p-6 relative overflow-hidden group transition-all duration-500
                         hover:shadow-2xl hover:shadow-primary/10"
              style={{ animationDelay: `${idx * 100}ms` }}
            >
              {/* Decorative corner gradient */}
              <div className={`absolute -top-16 -right-16 w-32 h-32 bg-gradient-to-br ${cert.color} opacity-20 rounded-full blur-2xl
                              group-hover:opacity-40 group-hover:scale-150 transition-all duration-700`} />

              <div className="relative">
                {/* Badge icon */}
                <div
                  className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${cert.color} flex items-center justify-center mb-6
                             group-hover:scale-110 group-hover:shadow-lg transition-all duration-300`}
                >
                  <Award className="w-8 h-8 text-white" />
                </div>

                {/* Verified badge */}
                <div className="flex items-center gap-2 mb-3">
                  <CheckCircle className="w-4 h-4 text-success" />
                  <span className="text-success text-xs font-medium">Verified</span>
                </div>

                {/* Content */}
                <h3 className="text-lg font-bold text-white mb-2 group-hover:text-sky transition-colors">
                  {cert.title}
                </h3>
                <p className="text-textSecondary text-xs leading-relaxed">{cert.description}</p>

                {/* Bottom gradient line */}
                <div
                  className={`absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r ${cert.color} opacity-0
                             group-hover:opacity-100 transition-opacity duration-300 rounded-b-2xl`}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
