import { Mail, Phone, MapPin, GraduationCap, Github, Linkedin, ExternalLink } from 'lucide-react';

const contactInfo = [
  {
    icon: Mail,
    label: 'Email',
    value: 'anusha.neelisetty06@gmail.com',
    href: 'mailto:anusha.neelisetty06@gmail.com',
    color: 'from-primary to-violet',
  },
  {
    icon: Phone,
    label: 'Phone',
    value: '+91 8977716589',
    href: 'tel:+918977716589',
    color: 'from-violet to-purple',
  },
  {
    icon: MapPin,
    label: 'Location',
    value: 'Andhra Pradesh, India',
    href: null,
    color: 'from-purple to-sky',
  },
  {
    icon: GraduationCap,
    label: 'Education',
    value: 'Raghu Engineering College | B.Tech CSE | CGPA 8.77',
    href: null,
    color: 'from-sky to-teal',
  },
];

const socialLinks = [
  {
    icon: Github,
    label: 'GitHub',
    href: 'https://github.com/anushaneelisetty06-star',
    color: 'hover:bg-white/10 hover:border-white/30',
  },
  {
    icon: Linkedin,
    label: 'LinkedIn',
    href: 'https://linkedin.com/in/anusha-neelisetty',
    color: 'hover:bg-sky/20 hover:border-sky/40',
  },
];

export default function Contact() {
  return (
    <section id="contact" className="py-20 lg:py-32 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-0 right-1/4 w-[600px] h-[600px] bg-primary/20 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-1/4 w-[600px] h-[600px] bg-violet/20 rounded-full blur-3xl" />
      </div>

      {/* Gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-card/20 to-transparent" />

      <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-16">
          <h2 className="section-title">
            <span className="gradient-text">Professional Profile</span>
          </h2>
          <p className="section-subtitle">
            Connect with me for data analytics opportunities
          </p>
        </div>

        {/* Professional Information Card */}
        <div className="glass rounded-3xl p-8 lg:p-10 relative overflow-hidden group">
          {/* Decorative gradient */}
          <div className="absolute top-0 right-0 w-72 h-72 bg-gradient-to-br from-primary/20 to-violet/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
          <div className="absolute bottom-0 left-0 w-72 h-72 bg-gradient-to-tr from-sky/20 to-teal/20 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-700" />

          <div className="relative">
            {/* Header */}
            <div className="flex items-center gap-4 mb-8 pb-8 border-b border-white/10">
              <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary to-violet flex items-center justify-center">
                <Mail className="w-7 h-7 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">Contact Information</h3>
                <p className="text-textSecondary text-sm">Get in touch for collaboration opportunities</p>
              </div>
            </div>

            {/* Contact items */}
            <div className="grid md:grid-cols-2 gap-4 mb-8">
              {contactInfo.map((contact, idx) => (
                contact.href ? (
                  <a
                    key={idx}
                    href={contact.href}
                    className="flex items-start gap-4 p-5 rounded-xl bg-white/5 border border-white/10
                             hover:bg-white/10 hover:border-primary/30 transition-all duration-300 group/item"
                  >
                    <div
                      className={`w-12 h-12 rounded-xl bg-gradient-to-br ${contact.color} flex items-center justify-center
                                 group-hover/item:scale-110 transition-transform duration-300 flex-shrink-0`}
                    >
                      <contact.icon className="w-5 h-5 text-white" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-textSecondary text-xs mb-1 uppercase tracking-wider">{contact.label}</div>
                      <div className="text-white font-medium text-sm break-words">{contact.value}</div>
                    </div>
                    <ExternalLink className="w-4 h-4 text-textSecondary ml-auto opacity-0 group-hover/item:opacity-100 transition-opacity flex-shrink-0" />
                  </a>
                ) : (
                  <div
                    key={idx}
                    className="flex items-start gap-4 p-5 rounded-xl bg-white/5 border border-white/10"
                  >
                    <div
                      className={`w-12 h-12 rounded-xl bg-gradient-to-br ${contact.color} flex items-center justify-center flex-shrink-0`}
                    >
                      <contact.icon className="w-5 h-5 text-white" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-textSecondary text-xs mb-1 uppercase tracking-wider">{contact.label}</div>
                      <div className="text-white font-medium text-sm break-words">{contact.value}</div>
                    </div>
                  </div>
                )
              ))}
            </div>

            {/* Social links */}
            <div className="pt-8 border-t border-white/10">
              <div className="text-textSecondary text-sm mb-4 uppercase tracking-wider">Connect on Social</div>
              <div className="flex gap-4">
                {socialLinks.map((social, idx) => (
                  <a
                    key={idx}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`flex-1 flex items-center justify-center gap-3 px-6 py-4 rounded-xl border border-white/10
                             ${social.color} transition-all duration-300 group/social`}
                    aria-label={social.label}
                  >
                    <social.icon className="w-5 h-5 text-textSecondary group-hover/social:text-white transition-colors" />
                    <span className="text-textSecondary group-hover/social:text-white transition-colors font-medium">
                      {social.label}
                    </span>
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
