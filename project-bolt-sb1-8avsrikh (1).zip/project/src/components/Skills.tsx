import { Code, Database, BarChart3, LineChart, GitBranch, Briefcase, Sparkles } from 'lucide-react';

const skillCategories = [
  {
    title: 'Programming',
    icon: Code,
    color: 'from-primary to-violet',
    skills: [
      { name: 'Python', level: 90 },
      { name: 'SQL', level: 85 },
      { name: 'Java', level: 75 },
      { name: 'C', level: 70 },
    ],
  },
  {
    title: 'Analytics Libraries',
    icon: LineChart,
    color: 'from-violet to-purple',
    skills: [
      { name: 'Pandas', level: 90 },
      { name: 'NumPy', level: 85 },
      { name: 'Scikit-Learn', level: 75 },
      { name: 'Matplotlib', level: 85 },
    ],
  },
  {
    title: 'Visualization Tools',
    icon: BarChart3,
    color: 'from-purple to-sky',
    skills: [
      { name: 'Power BI', level: 90 },
      { name: 'Tableau', level: 80 },
      { name: 'Excel', level: 85 },
    ],
  },
  {
    title: 'Database',
    icon: Database,
    color: 'from-sky to-teal',
    skills: [
      { name: 'MySQL', level: 85 },
      { name: 'PostgreSQL', level: 70 },
    ],
  },
  {
    title: 'Professional Skills',
    icon: Briefcase,
    color: 'from-teal to-primary',
    skills: [
      { name: 'Data Cleaning', level: 90 },
      { name: 'Business Intelligence', level: 85 },
      { name: 'Dashboard Design', level: 85 },
      { name: 'Statistical Analysis', level: 80 },
      { name: 'Data Storytelling', level: 85 },
    ],
  },
  {
    title: 'Tools & Version Control',
    icon: GitBranch,
    color: 'from-primary to-violet',
    skills: [
      { name: 'GitHub', level: 85 },
      { name: 'Jupyter Notebook', level: 90 },
      { name: 'VS Code', level: 90 },
    ],
  },
];

export default function Skills() {
  return (
    <section id="skills" className="py-20 lg:py-32 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-1/4 left-1/4 w-[600px] h-[600px] bg-primary/20 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-[600px] h-[600px] bg-violet/20 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-16">
          <h2 className="section-title">
            <span className="gradient-text">Technical Skills</span>
          </h2>
          <p className="section-subtitle">
            A comprehensive toolkit for transforming data into actionable insights
          </p>
        </div>

        {/* Skills grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {skillCategories.map((category, idx) => (
            <div
              key={idx}
              className="card glass-hover group"
              style={{ animationDelay: `${idx * 100}ms` }}
            >
              {/* Header */}
              <div className="flex items-center gap-3 mb-6">
                <div
                  className={`w-12 h-12 rounded-xl bg-gradient-to-br ${category.color} flex items-center justify-center
                             group-hover:scale-110 transition-transform duration-300`}
                >
                  <category.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-bold text-white">{category.title}</h3>
              </div>

              {/* Skills list */}
              <div className="space-y-4">
                {category.skills.map((skill, skillIdx) => (
                  <div key={skillIdx}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-textSecondary">{skill.name}</span>
                      <span className="text-xs text-textSecondary">{skill.level}%</span>
                    </div>
                    <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                      <div
                        className={`h-full bg-gradient-to-r ${category.color} rounded-full transition-all duration-1000
                                   group-hover:opacity-100`}
                        style={{ width: `${skill.level}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Skill highlights */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Programming Languages', value: '4+', icon: Code },
            { label: 'Analytics Tools', value: '10+', icon: Sparkles },
            { label: 'Visualization Platforms', value: '3', icon: BarChart3 },
            { label: 'Database Systems', value: '2', icon: Database },
          ].map((highlight, idx) => (
            <div
              key={idx}
              className="glass rounded-xl p-6 text-center hover:bg-white/10 transition-all duration-300"
            >
              <highlight.icon className="w-8 h-8 text-primary mx-auto mb-3" />
              <div className="text-3xl font-bold text-white mb-1">{highlight.value}</div>
              <div className="text-xs text-textSecondary">{highlight.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
