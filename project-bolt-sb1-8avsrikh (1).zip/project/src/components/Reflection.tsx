import { Quote, Sparkles, Brain, Target, LineChart, CheckCircle, Lightbulb } from 'lucide-react';

const growthAreas = [
  {
    icon: Brain,
    title: 'Analytical Thinking',
    description: 'Developed a structured approach to problem-solving, learning to break down complex datasets into actionable insights.',
    color: 'from-primary to-violet',
  },
  {
    icon: LineChart,
    title: 'Business Intelligence',
    description: 'Gained expertise in translating raw data into strategic business recommendations that drive decision-making.',
    color: 'from-violet to-purple',
  },
  {
    icon: Target,
    title: 'Dashboard Development',
    description: 'Mastered the art of creating intuitive, interactive dashboards that communicate insights effectively.',
    color: 'from-purple to-sky',
  },
  {
    icon: CheckCircle,
    title: 'Statistical Validation',
    description: 'Strengthened ability to validate findings through rigorous statistical testing and hypothesis validation.',
    color: 'from-sky to-teal',
  },
];

export default function Reflection() {
  return (
    <section id="reflection" className="py-20 lg:py-32 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-card/30 to-background" />
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-1/4 left-1/4 w-[600px] h-[600px] bg-primary/20 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-[600px] h-[600px] bg-violet/20 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-16">
          <h2 className="section-title">
            <span className="gradient-text">Professional Reflection</span>
          </h2>
          <p className="section-subtitle">
            Key takeaways from the data analytics internship journey
          </p>
        </div>

        {/* Main quote card */}
        <div className="glass rounded-3xl p-8 md:p-12 lg:p-16 text-center relative overflow-hidden mb-16">
          {/* Decorative elements */}
          <div className="absolute top-0 left-0 w-48 h-48 bg-primary/10 rounded-full blur-2xl" />
          <div className="absolute bottom-0 right-0 w-48 h-48 bg-violet/10 rounded-full blur-2xl" />

          {/* Quote icon */}
          <div className="w-16 h-16 mx-auto mb-8 rounded-2xl bg-gradient-to-br from-primary to-violet flex items-center justify-center">
            <Quote className="w-8 h-8 text-white" />
          </div>

          {/* Main text */}
          <blockquote className="text-xl md:text-2xl lg:text-3xl text-white font-light leading-relaxed mb-8">
            Throughout my <span className="text-primary font-medium">Data Analytics Internship</span> journey,
            I transformed <span className="text-violet font-medium">raw datasets</span> into{' '}
            <span className="text-purple font-medium">actionable insights</span> through cleaning, analysis,
            visualization, dashboarding, storytelling, and statistical validation. This experience strengthened my{' '}
            <span className="text-sky font-medium">analytical mindset</span>,{' '}
            <span className="text-teal font-medium">technical expertise</span>, and ability to communicate
            business insights <span className="text-primary font-medium">effectively</span>.
          </blockquote>

          {/* Divider */}
          <div className="w-20 h-1 bg-gradient-to-r from-primary via-violet to-teal mx-auto rounded-full mb-6" />

          {/* Signature */}
          <div className="flex items-center justify-center gap-3">
            <Sparkles className="w-5 h-5 text-primary" />
            <span className="text-textSecondary font-medium">Neelisetty Anusha</span>
            <Sparkles className="w-5 h-5 text-violet" />
          </div>
        </div>

        {/* Growth areas */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {growthAreas.map((area, idx) => (
            <div
              key={idx}
              className="glass rounded-2xl p-6 relative overflow-hidden group hover:shadow-2xl hover:shadow-primary/10 transition-all duration-500"
            >
              {/* Gradient on hover */}
              <div className={`absolute inset-0 bg-gradient-to-br ${area.color} opacity-0 group-hover:opacity-5 transition-opacity duration-500`} />

              <div className="relative">
                <div
                  className={`w-12 h-12 rounded-xl bg-gradient-to-br ${area.color} flex items-center justify-center mb-4
                             group-hover:scale-110 group-hover:shadow-lg transition-all duration-300`}
                >
                  <area.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-bold text-white mb-2 group-hover:text-sky transition-colors">
                  {area.title}
                </h3>
                <p className="text-textSecondary text-sm leading-relaxed">
                  {area.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Highlight stat */}
        <div className="mt-16 text-center">
          <div className="inline-flex items-center gap-6 glass rounded-2xl p-6">
            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-success/20 to-teal/20 flex items-center justify-center">
              <Lightbulb className="w-7 h-7 text-success" />
            </div>
            <div className="text-left">
              <div className="text-2xl font-bold text-white">5 Tasks Completed</div>
              <div className="text-textSecondary text-sm">Comprehensive data analytics skill development</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
